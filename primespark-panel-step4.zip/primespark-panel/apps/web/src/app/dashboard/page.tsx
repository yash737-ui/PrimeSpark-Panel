"use client";

import { Server, Gauge, HardDrive, Activity } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@primespark/ui";
import { useAuth } from "@/lib/auth-context";
import { StatCard } from "@/components/dashboard/stat-card";

export default function DashboardPage() {
  const { user } = useAuth();
  const displayName = user?.name?.trim() || user?.email || "there";

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Welcome back, {displayName}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Here&apos;s an overview of your PrimeSpark Panel account.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Servers" icon={Server} />
        <StatCard label="Active Players" icon={Activity} />
        <StatCard label="Storage Used" icon={HardDrive} />
        <StatCard label="Avg. Uptime" icon={Gauge} />
      </div>

      <Card className="border-white/10 bg-white/[0.03] backdrop-blur-xl">
        <CardHeader>
          <CardTitle>No servers yet</CardTitle>
          <CardDescription>
            Server management hasn&apos;t been built yet — this is a placeholder for what will
            become your server list.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex h-40 items-center justify-center rounded-lg border border-dashed border-border text-sm text-muted-foreground">
            Server management arrives in a future update
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
