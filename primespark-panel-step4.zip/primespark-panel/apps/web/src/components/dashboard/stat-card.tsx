import { Card, CardContent, CardHeader, CardTitle } from "@primespark/ui";

interface StatCardProps {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

export function StatCard({ label, icon: Icon }: StatCardProps) {
  return (
    <Card className="border-white/10 bg-white/[0.03] backdrop-blur-xl">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-semibold tracking-tight text-foreground">—</div>
        <p className="mt-1 text-xs text-muted-foreground">No data yet</p>
      </CardContent>
    </Card>
  );
}
