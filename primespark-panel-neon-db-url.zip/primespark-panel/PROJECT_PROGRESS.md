# PrimeSpark Panel — Project Progress

Tracks what has been built so far, at a feature level. Update this file as
each future step is completed.

## ✅ Completed

**Step 1 — Foundation**
- [x] Monorepo structure (`apps/`, `packages/`, `prisma/`) using pnpm workspaces
- [x] `apps/web` — Next.js 15 + React + TypeScript app scaffold
- [x] Tailwind CSS configured for `apps/web`
- [x] shadcn/ui initialized (`components.json`, CSS variables, `cn()` utility)
- [x] `apps/api` — Express + TypeScript app scaffold with a bare `/health` route
- [x] Prisma configured with a PostgreSQL datasource (no models yet)
- [x] Shared packages scaffolded: `packages/ui`, `packages/config`, `packages/types`
- [x] Root ESLint + Prettier configuration
- [x] `.env.example` with placeholders for database and app config
- [x] Base documentation (`README.md`, this file, `DEVELOPMENT_LOG.md`)

**Step 2 — Development Environment Setup & Preview**
- [x] Audited every `import`/`require` in the codebase against each `package.json` and
      filled in dependencies that were missing (`tailwindcss-animate`,
      `prettier-plugin-tailwindcss`, `@eslint/js`, `typescript-eslint`, `@eslint/eslintrc`)
- [x] `.env` created locally from `.env.example` for development configuration
- [x] Verified TypeScript configuration — all `.ts`/`.tsx` files parse with no syntax errors
      (root, `apps/web`, `apps/api`, `packages/ui`, `packages/types` tsconfigs all validated)
- [x] Verified Tailwind CSS setup — config content paths, PostCSS pipeline, and CSS variables
      all confirmed correct; theme shifted to a blue primary palette
- [x] Verified shadcn/ui setup — `components.json`, `cn()` utility, and CSS variable tokens
      confirmed in place
- [x] Verified Prisma schema syntax (valid `generator` + `datasource` blocks); PostgreSQL
      connection is driven by `DATABASE_URL` in `.env`
- [x] Added `GET /health` (liveness) and `GET /health/db` (PostgreSQL connectivity check via
      Prisma) endpoints on the API
- [x] Built the PrimeSpark Panel landing page (`apps/web/src/app/page.tsx`) — blue premium
      theme, responsive layout, nav placeholder, feature grid, no functional auth/dashboard
- [x] Validated every JSON config file in the repo parses correctly
- [x] All JSON/TS syntax checks completed successfully in the sandbox

**⚠️ Not verified in this environment:** actually running `pnpm install`, `pnpm dev:web`,
`pnpm dev:api`, or `prisma generate`/`prisma validate` — this sandbox has no outbound network
access, so the package registry is unreachable. Everything above was verified statically
(JSON parsing, TypeScript syntax checks, manual dependency-to-import cross-referencing). Run
the commands in the README/DEVELOPMENT_LOG on a machine with network access to do a live boot
test.

**Step 3 — Authentication System**
- [x] Prisma schema: `User`, `RefreshToken`, `EmailVerificationToken`, `PasswordResetToken`,
      `AuditLog` models + `Role` enum (`ADMIN` / `USER`)
- [x] Password hashing with bcrypt (`apps/api/src/lib/password.ts`)
- [x] JWT access tokens (15m default) + rotating refresh tokens (7d default, stored hashed,
      delivered as an httpOnly cookie) (`apps/api/src/lib/jwt.ts`)
- [x] Auth endpoints: `POST /api/auth/register`, `login`, `logout`, `refresh`,
      `forgot-password`, `reset-password`, `verify-email`, and `GET /api/auth/me`
- [x] Zod request validation middleware (`apps/api/src/middleware/validate.ts`), schemas shared
      with the frontend via `@primespark/types`
- [x] Authentication middleware (`authenticate`) verifying the JWT access token
- [x] Role-Based Access Control middleware (`authorize`), ready for future protected routes
- [x] Audit logging (`apps/api/src/lib/audit.ts`) for register/login (success + failure)/logout/
      refresh/password-reset/email-verification events
- [x] Email verification structure — token generated and stored (hashed) on registration; no
      email provider wired up yet, so the raw token is only echoed back in non-production
      responses for testing
- [x] Frontend pages: Login, Register, Forgot Password, Reset Password, Email Verification
      (`apps/web/src/app/(auth)/*`), all client-validated with `react-hook-form` + the shared
      zod schemas, blue PrimeSpark theme, shared `AuthLayout`
- [x] Shared shadcn/ui primitives built out in `packages/ui`: `Button`, `Input`, `Label`, `Card`
- [x] Frontend API client (`apps/web/src/lib/api-client.ts`, `auth-api.ts`) with typed errors
- [x] `.env.example` extended with `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`,
      `JWT_ACCESS_EXPIRES_IN`, `JWT_REFRESH_EXPIRES_IN_DAYS`, `BCRYPT_SALT_ROUNDS`, `CLIENT_URL`
- [x] Full dependency-to-import audit and TypeScript syntax check across every new/changed file

**⚠️ Not verified in this environment (same network limitation as Step 2):** live
`pnpm install`, running the actual dev servers, `prisma migrate dev` against a real Postgres
instance, and exercising the endpoints with real HTTP requests. All checks were static
(TypeScript syntax validation + JSON validation + manual import/dependency cross-referencing).

**⚠️ Known scope limitation:** no email provider is integrated, so "email verification" and
"forgot password" are structurally complete (tokens are generated, hashed, stored, and
validated correctly) but the emails themselves are not sent — the raw tokens are only returned
in the API response outside of `NODE_ENV=production`, purely so the flow can be tested end to
end before an email provider is added.

**Step 3 (fix) — Control Panel UI Rework (Login-First) + Dashboard Shell**
*(This was originally logged as "Step 4" but is a correction/extension of Step 3's frontend, not the real Step 4. Renamed here for accurate numbering; the actual Step 4 — Dashboard Foundation — follows below.)*
- [x] Removed the marketing landing page entirely (no hero, feature cards, "Get Started",
      "Explore Features") — deleted the old `apps/web/src/app/page.tsx` content
- [x] Root route `/` now renders the Login page directly (same `LoginForm` component as
      `/login`), so there is no separate marketing homepage at any URL
- [x] Rebuilt the visual design as an original, Pterodactyl-inspired (not copied) game hosting
      control panel: dark theme by default, blue accent (`#2563EB` / `hsl(221 83% 53%)`),
      glassmorphism cards (`bg-white/[0.03]` + `backdrop-blur-xl` + subtle border), ambient
      glow + grid-pattern background, Inter font via `next/font/google`, fade-in-up and
      glow-pulse animations
- [x] Login page now includes: email field, password field with show/hide toggle
      (`PasswordInput`), a real "Remember me" checkbox, forgot-password link, login button with
      a loading state, a dedicated error-message region, and Zod validation
- [x] "Remember me" is wired end-to-end: unchecked → session cookie (cleared when the browser
      closes); checked → persistent cookie for the refresh-token lifetime (backend:
      `apps/api/src/modules/auth/auth.controller.ts`, schema: `loginSchema` in
      `@primespark/types` now includes `rememberMe`)
- [x] Client-side session state: `AuthProvider`/`useAuth` (`apps/web/src/lib/auth-context.tsx`)
      silently exchanges the httpOnly refresh cookie for a fresh access token on app load, so
      sessions persist across reloads without storing tokens in `localStorage`
- [x] Route guards: `RequireGuest` (login/register/forgot-password redirect an already-logged-in
      user to `/dashboard`) and `RequireAuth` (dashboard redirects guests to `/login`)
- [x] `reset-password` and `verify-email` are intentionally **not** guest-gated, since
      registering logs a user in immediately and they may need to verify email while
      authenticated
- [x] New shared shadcn/ui primitives in `packages/ui`: `Checkbox`, `PasswordInput`,
      `DropdownMenu` (Trigger/Content/Item/Label/Separator), `Avatar`
- [x] New placeholder `/dashboard` route (protected by `RequireAuth`): responsive `Sidebar`
      (collapses behind a mobile menu button below `md`), `Topbar`, `UserMenu` (avatar dropdown
      with user info + working Logout), a welcome message using the real logged-in user's name,
      and four empty stat cards (Servers / Active Players / Storage Used / Avg. Uptime) — no
      Minecraft server management logic
- [x] Sidebar nav items beyond "Dashboard" are visibly marked "Soon" and non-interactive —
      placeholders only, as scoped
- [x] Full rename verification re-run: zero live "PowerSpark" references anywhere in the
      project (only intentional historical changelog entries remain)
- [x] Full dependency-to-import audit (found no gaps this pass) and TypeScript syntax check
      across every new/changed file; all JSON configs re-validated

**⚠️ Not verified in this environment (same network limitation as prior steps):** live
`pnpm install`, running the actual dev servers, or clicking through the UI in a browser. All
checks were static (TypeScript syntax validation, JSON validation, manual import/dependency
cross-referencing). The login → dashboard → logout flow, mobile sidebar behavior, and
glassmorphism rendering should all be spot-checked in a real browser once dependencies are
installed.

## ⬜ Not Started Yet

- [ ] Email provider integration (actually sending verification/reset emails)
- [ ] Real dashboard data (server list, stats/activity backed by real records instead of
      placeholder responses)
- [ ] Server management features (create/start/stop/delete Minecraft servers)
- [ ] Native process management via Node.js `child_process`
- [ ] Real-time server console / log streaming (WebSockets)
- [ ] File manager functionality
- [ ] Backup functionality
- [ ] Scheduling functionality
- [ ] Node management logic
- [ ] Network/allocation management logic
- [ ] Activity log persistence (currently static placeholder entries)
- [ ] Settings and Account page functionality (currently empty placeholders)
- [ ] Deployment configuration

## Notes

- No Docker dependency by design — Minecraft server instances will run as
  native Linux processes launched via `child_process`.
- This file reflects foundation-stage status only; nothing beyond scaffolding
  has been implemented.
- The project was renamed from "PowerSpark Panel" to "PrimeSpark Panel" on
  2026-08-04 (branding only, no functional change) — see `DEVELOPMENT_LOG.md`
  for the full list of renamed identifiers.

---

**Step 4 — Dashboard Foundation**
- [x] Backend: `GET /api/dashboard/stats` and `GET /api/dashboard/activity`
      (`apps/api/src/modules/dashboard/`), both returning static placeholder data (explicitly
      commented as non-live — no real metrics collection exists), protected by the existing
      `authenticate` middleware — no changes to the auth module itself
- [x] Shared `DashboardStats` / `ActivityLogEntry` types added to `@primespark/types`
- [x] Frontend calls the new endpoints with the access token as a Bearer header
      (`apps/web/src/lib/dashboard-api.ts`) — no changes to `api-client.ts` or the auth context
- [x] Theme system added: `ThemeProvider`/`useTheme` (dark by default, toggleable, persisted to
      `localStorage`), a blocking init script in the root layout to avoid a flash of the wrong
      theme, and real light-theme CSS variables added alongside the existing dark palette
- [x] Toast notifications wired up via `sonner`, mounted globally in the root layout
- [x] Sidebar rebuilt: full nav list (Dashboard, Servers, Nodes, Users, Files, Backups,
      Schedules, Network, Activity Logs, Settings, Account) with Lucide icons, active-route
      highlighting, a working collapse toggle (desktop), and a working Logout button — all as
      real routed pages, not disabled "Soon" placeholders
- [x] Top navigation rebuilt: breadcrumb trail doubling as the current page title, a
      presentational global search input, theme toggle, notifications dropdown (static
      placeholder entries), and the existing user profile dropdown
- [x] New reusable components: `DashboardCard`, `ChartCard` (recharts, static placeholder
      series), `ActivityFeed`, `QuickActions` (wired to toast notifications on click),
      `EmptyState`, `ErrorState` (with retry), `PlaceholderPage`, plus an extended `StatCard`
- [x] New shared `Skeleton` primitive added to `packages/ui`
- [x] Dashboard Home rewritten to actually fetch from the two new endpoints: real loading-
      skeleton state, real error-state-with-retry, and on success renders all 8 requested stat
      cards (Total/Running/Offline Servers, CPU/RAM/Disk/Network Usage, Active Users), 3 charts
      (CPU/RAM/Network trend), Recent Activity, System Status, and Quick Actions
- [x] 10 new placeholder section pages created and routed (`/dashboard/servers`, `/nodes`,
      `/users`, `/files`, `/backups`, `/schedules`, `/network`, `/activity-logs`, `/settings`,
      `/account`), each using the shared `PlaceholderPage` + `EmptyState` composition with
      distinct copy — clean layouts ready for future implementation, no real logic
- [x] All dashboard routes remain protected by the existing `RequireAuth` guard on
      `apps/web/src/app/dashboard/layout.tsx` (unmodified) — every new page inherits this
      automatically since Next.js layouts wrap all nested routes
- [x] Full dependency-to-import audit (no gaps found), full TypeScript syntax check across
      every new/changed file (zero errors), all JSON configs re-validated, confirmed zero
      "PowerSpark" residue outside intentional changelog history

**Explicitly not implemented, as scoped:** Minecraft server creation, server management,
console, file manager functionality, backup functionality, scheduling functionality, node
management logic, WebSockets, and resource-monitoring logic. The stats/charts on the dashboard
home page are static placeholder numbers from the backend, not live measurements.

**⚠️ Not verified in this environment (same network limitation as every prior step):** live
`pnpm install`, running the actual dev servers, or clicking through the dashboard in a browser
(sidebar collapse, mobile nav, theme toggle, toast notifications, chart rendering). All
verification was static. These should all be spot-checked in a real browser once dependencies
are installed.
