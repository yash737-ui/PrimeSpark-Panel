// PrimeSpark Panel - Shared Dashboard Types
// Shapes for the placeholder dashboard endpoints. Values behind these
// types are static placeholder data for now - no real metrics collection
// or resource monitoring exists yet.

export interface DashboardStats {
  totalServers: number;
  runningServers: number;
  offlineServers: number;
  cpuUsagePercent: number;
  ramUsagePercent: number;
  diskUsagePercent: number;
  networkUsageMbps: number;
  activeUsers: number;
  systemStatus: "operational" | "degraded" | "outage";
  cpuHistory: number[];
  ramHistory: number[];
  networkHistory: number[];
}

export interface ActivityLogEntry {
  id: string;
  message: string;
  actor: string;
  createdAt: string;
}

export interface DashboardActivityResponse {
  entries: ActivityLogEntry[];
}
