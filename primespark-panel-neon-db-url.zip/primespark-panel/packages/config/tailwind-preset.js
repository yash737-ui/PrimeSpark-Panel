// PrimeSpark Panel - Shared Tailwind Preset
// Placeholder for shared Tailwind theme tokens (colors, spacing, fonts)
// to be consumed via `presets: [require("@primespark/config/tailwind-preset")]`
// once the design system is defined.

/** @type {Partial<import('tailwindcss').Config>} */
module.exports = {};
