# PrimeSpark Panel — Development Log

A running, dated log of development activity. Add a new entry each time
meaningful work is done on the project.

---

## 2026-08-03 — Project Foundation

**Type:** Scaffolding

Created the initial monorepo foundation for PrimeSpark Panel. No application
logic, authentication, dashboard, server management, or API features were
implemented — this step was structure only.

**Added:**
- pnpm workspace monorepo (`apps/*`, `packages/*`)
- `apps/web`: Next.js 15 + React + TypeScript + Tailwind CSS + shadcn/ui setup
- `apps/api`: Node.js + Express + TypeScript scaffold with a single `/health` route
- `prisma/schema.prisma`: PostgreSQL datasource configured, no models yet
- `packages/ui`, `packages/config`, `packages/types`: empty shared package scaffolds
- Root-level ESLint, Prettier, `.env.example`, `.gitignore`
- `README.md`, `PROJECT_PROGRESS.md`, `DEVELOPMENT_LOG.md`

**Decisions:**
- No Docker — Minecraft server instances will run as native Linux processes
  via Node.js `child_process` in a later step.
- shadcn/ui components will be generated on-demand into `packages/ui` rather
  than pre-generating a full component set.

**Next step:** Define the Prisma data models (users, Minecraft servers,
sessions/roles) — see the prompt provided at the end of the foundation setup.

---

## 2026-08-04 — Development Environment Setup & Preview

**Type:** Verification / Configuration

Set up and verified the development environment. No application logic
(auth, dashboard, server management, file manager, console, billing) was
added — this step was setup, verification, and a preview landing page only.

**Added / Changed:**
- `.env` created locally from `.env.example`
- `apps/api/src/index.ts`: added `GET /health/db` — checks PostgreSQL
  connectivity via `prisma.$queryRaw` (alongside the existing `GET /health`
  liveness check)
- `apps/web/src/app/page.tsx`: built the PrimeSpark Panel landing page —
  nav bar with placeholder links, hero section, feature grid, footer;
  blue premium theme; fully responsive
- `apps/web/src/app/globals.css`: shifted CSS variable theme tokens to a
  blue primary color (light + dark mode)
- Dependency audit: cross-referenced every `import`/`require` against each
  `package.json` and added what was missing:
  - `apps/web`: `tailwindcss-animate`, `@eslint/eslintrc`
  - `apps/api`: `@eslint/js`, `typescript-eslint`
  - root: `@eslint/js`, `typescript-eslint`, `eslint`, `prettier-plugin-tailwindcss`

**Verification performed:**
- All JSON config files across the repo parse successfully
- All `.ts`/`.tsx` source files pass a TypeScript syntax check (no parse errors)
- `pnpm-workspace.yaml` structure confirmed correct
- Prisma schema manually reviewed — valid `generator`/`datasource` blocks
- Tailwind config content paths and PostCSS pipeline confirmed correct
- shadcn/ui `components.json` and `cn()` utility confirmed in place

**Known limitation:** this sandbox has no outbound network access, so
`pnpm install`, `pnpm dev:web`, `pnpm dev:api`, and `prisma generate` could
not be executed live here. All checks above were done statically. These
commands should be run on a machine with network access to complete a live
boot test — see README.md for exact commands.

**Next step:** Build the authentication module.

---

## 2026-08-04 — Authentication System

**Type:** Feature (Backend + Frontend)

Built the full authentication module end to end. No server management,
dashboard, file manager, console, or billing logic was added — this step
was authentication only, as scoped.

**Prisma (`prisma/schema.prisma`):**
- Added `Role` enum (`ADMIN`, `USER`)
- Added `User` model (email, hashed password, name, role, emailVerified)
- Added `RefreshToken` model — tokens stored hashed, rotated on every use,
  revocable
- Added `EmailVerificationToken` and `PasswordResetToken` models — both
  store only a hash of the token, single-use (`usedAt`), time-limited
- Added `AuditLog` model — append-only, indexed on `userId` and `action`

**Backend (`apps/api`):**
- `src/lib/prisma.ts` — Prisma client singleton (avoids connection-pool
  exhaustion on dev hot-reload)
- `src/lib/password.ts` — bcrypt hashing/comparison (configurable salt
  rounds via `BCRYPT_SALT_ROUNDS`)
- `src/lib/tokens.ts` — cryptographically random raw tokens for
  verification/reset links; SHA-256 hash stored at rest
- `src/lib/jwt.ts` — access token (15m default) + refresh token (7d
  default) signing/verification
- `src/lib/audit.ts` — `recordAuditLog()` + `AuditAction` constants;
  failures are logged, never thrown, so audit logging can't break auth
- `src/middleware/validate.ts` — generic zod validation middleware,
  returns field-level error messages
- `src/middleware/authenticate.ts` — verifies the `Authorization: Bearer`
  access token, attaches `req.user`
- `src/middleware/authorize.ts` — RBAC middleware (`authorize("ADMIN")`),
  ready for future protected routes; not yet applied to any route beyond
  the example `GET /api/auth/me`
- `src/middleware/error-handler.ts` — centralized error handler
- `src/modules/auth/{auth.service,auth.controller,auth.routes}.ts` —
  register, login, logout, refresh (rotating), forgot-password,
  reset-password, verify-email, me
- Refresh tokens are delivered as an httpOnly, `SameSite=Lax` cookie
  scoped to `/api/auth`, not returned in the JSON body
- `src/index.ts` — wired in `cookie-parser`, CORS with `credentials: true`
  restricted to `CLIENT_URL`, mounted `/api/auth`, added the error handler

**Frontend (`apps/web`):**
- `src/app/(auth)/layout.tsx` — shared centered layout with PrimeSpark
  branding
- `src/app/(auth)/login/page.tsx`, `register/page.tsx`,
  `forgot-password/page.tsx`, `reset-password/page.tsx`,
  `verify-email/page.tsx` — built with `react-hook-form` +
  `@hookform/resolvers/zod`, validated against the same zod schemas the
  backend uses
- `src/lib/api-client.ts` — typed fetch wrapper (`credentials: "include"`
  for the refresh cookie, normalizes errors into `ApiError`)
- `src/lib/auth-api.ts` — one function per auth endpoint

**Shared packages:**
- `packages/types/src/schemas/auth.ts` — zod schemas
  (`registerSchema`, `loginSchema`, `forgotPasswordSchema`,
  `resetPasswordSchema`, `verifyEmailSchema`), used by both apps
- `packages/types/src/auth.ts` — `Role`, `AuthUser`, API response shapes
- `packages/ui/src/{button,input,label,card}.tsx` — first real shadcn/ui
  components, built out to support the auth forms

**Design decisions:**
- Refresh tokens rotate on every use and are stored hashed — a stolen,
  already-used refresh token cannot be replayed
- Password reset invalidates all of a user's existing sessions
  (all refresh tokens revoked in the same transaction)
- Login/forgot-password responses don't reveal whether an email is
  registered, to avoid user enumeration
- Email verification and password reset are structurally complete but no
  email provider is wired up yet — the raw token is only echoed back in
  the API response when `NODE_ENV !== "production"`, so the flow can be
  tested end-to-end today and swapped for real email sending later
  without changing the token logic

**Verification performed:** every new/changed `.ts`/`.tsx` file across
`apps/api`, `apps/web`, `packages/ui`, and `packages/types` passed a
TypeScript syntax check; every `package.json` was cross-referenced against
actual `import`/`require` statements and missing dependencies were added;
all JSON configs validated.

**Known limitation (same as Step 2):** no outbound network access in this
sandbox, so `pnpm install`, live dev servers, and `prisma migrate dev`
against a real database were not executed here — verification was static.

**Next step:** Prisma data models and API/UI for Minecraft server
management (server dashboard groundwork).

---

## 2026-08-04 — Rebrand: PowerSpark Panel → PrimeSpark Panel

**Type:** Rename (no functional change)

Renamed the project from "PowerSpark Panel" to "PrimeSpark Panel"
everywhere. No behavior, logic, routes, or schema fields changed — this
was a text/identifier substitution only.

**Renamed:**
- Display name/branding: every "PowerSpark Panel" occurrence in
  `README.md`, `PROJECT_PROGRESS.md`, `DEVELOPMENT_LOG.md`, page titles,
  metadata, the landing page, the auth layout logo/wordmark, and code
  comments
- npm workspace scope: `@powerspark/*` → `@primespark/*` across every
  `package.json`, `tsconfig.json` path alias, and import statement in
  `apps/web`, `apps/api`, `packages/ui`, `packages/types`
- Root package name: `powerspark-panel` → `primespark-panel`
- Project directory: `powerspark-panel/` → `primespark-panel/`
- Refresh-token cookie name: `powerspark_refresh_token` →
  `primespark_refresh_token`
- API health-check service identifier: `powerspark-api` → `primespark-api`
- Example database name in `.env.example`: `powerspark_panel` →
  `primespark_panel`

**Verification performed:** confirmed zero remaining case-insensitive
occurrences of "powerspark" anywhere in the project; re-ran the full
TypeScript syntax check and JSON validation across every file — all
passed.

**Next step (unchanged):** Prisma data models and API/UI for Minecraft
server management (server dashboard groundwork).

---

## 2026-08-04 — Control Panel UI Rework: Login-First + Dashboard Shell (Step 3 fix)

*Correction note: this entry was originally logged without a step number and
was mistakenly treated as "Step 4" in conversation. It is actually a fix/
extension of Step 3's frontend (the auth pages and a first dashboard
placeholder), not the real Step 4. The actual Step 4 — Dashboard Foundation —
is logged further below.*

**Type:** Feature + Redesign (Frontend, small Backend addition)

Replaced the marketing landing page with a real control-panel front end:
the root route now opens the login page, sessions are tracked client-side,
protected/guest routing is enforced, and a placeholder dashboard exists
behind auth. No Minecraft server management was added - explicitly out of
scope for this step.

**Removed:**
- `apps/web/src/app/page.tsx` (the old hero/features/marketing homepage) -
  deleted outright, not just replaced

**Design:**
- Rewrote `globals.css` as a dark-first theme: deep navy background
  (`hsl(224 71% 4%)`), blue primary (`hsl(221 83% 53%)` = `#2563EB`), and
  added `--popover`/`--popover-foreground` tokens for the new dropdown menu
- `tailwind.config.ts`: added `--font-sans` font family hookup, `popover`
  color tokens, and `fade-in-up`/`glow-pulse` keyframe animations
- Root layout (`apps/web/src/app/layout.tsx`) now loads Inter via
  `next/font/google` and forces `<html class="dark">` - dark is the only
  theme for now, no toggle built yet
- New `AuthShell` component (`components/auth/auth-shell.tsx`): ambient
  blurred glow blobs, a subtle grid-pattern background, and the
  PrimeSpark Panel logo - shared by every auth page **and** the root page
  so `/` and `/login` render identically
- Auth cards use a glassmorphism treatment (`bg-white/[0.03]
  backdrop-blur-xl border-white/10 shadow-2xl`) throughout
- Explicitly an original design inspired by, but not copied from, modern
  hosting panels like Pterodactyl - no third-party assets, icons, or
  layouts were reused

**Session state & routing (`apps/web`):**
- `src/lib/auth-context.tsx` - new `AuthProvider`/`useAuth`. On mount,
  silently calls `POST /api/auth/refresh` to exchange the httpOnly refresh
  cookie for a fresh access token, so a reload doesn't lose the session.
  Access tokens live in memory only (never `localStorage`)
- `src/lib/auth-api.ts` - added `refreshRequest()`
- `src/components/auth/require-guest.tsx` - redirects an authenticated
  user away from login/register/forgot-password to `/dashboard`
- `src/components/auth/require-auth.tsx` - redirects a guest away from
  `/dashboard` to `/login`
- `reset-password` and `verify-email` are deliberately **not**
  guest-gated: registering logs the user in immediately (existing Step 3
  behavior), so a just-registered user clicking their verification link
  is already authenticated and must not be bounced away from that page

**Auth pages refactored into reusable components:**
- `components/auth/{login-form,register-form,forgot-password-form,
  reset-password-form,verify-email-content}.tsx` - the actual form logic,
  now used by both `/login` and `/` (login form) and by their respective
  route files
- Login form adds: a real "Remember me" checkbox (wired to backend cookie
  behavior, not decorative), a show/hide password toggle, a loading
  state, and a dedicated error-message region
- All forms still validate with the same Zod schemas from
  `@primespark/types` shared with the backend

**Backend addition (`apps/api`):**
- `loginSchema` (`packages/types/src/schemas/auth.ts`) gained
  `rememberMe: z.boolean().default(false)`
- `auth.controller.ts`: `setRefreshCookie()` now takes a `persistent`
  flag - unchecked "remember me" sets a session cookie (no `maxAge`,
  cleared when the browser closes); checked sets the existing persistent
  cookie. The refresh token's actual server-side expiry is unchanged
  either way

**New shared UI primitives (`packages/ui`):**
- `checkbox.tsx` - shadcn/ui Checkbox (Radix), used for "Remember me"
- `password-input.tsx` - `Input` wrapped with a show/hide toggle button
- `dropdown-menu.tsx` - shadcn/ui DropdownMenu set (Trigger/Content/Item/
  Label/Separator), used for the user profile menu
- `avatar.tsx` - shadcn/ui Avatar (Root/Image/Fallback)
- Added `lucide-react`, `@radix-ui/react-checkbox`,
  `@radix-ui/react-dropdown-menu`, `@radix-ui/react-avatar` as
  dependencies of `packages/ui`

**New dashboard (placeholder only, `apps/web/src/app/dashboard`):**
- `layout.tsx` - wraps content in `RequireAuth` + `DashboardShell`
- `page.tsx` - welcome message using the logged-in user's real name/email,
  four empty stat cards (Servers / Active Players / Storage Used /
  Avg. Uptime), and a "no servers yet" placeholder card
- `components/dashboard/{sidebar,topbar,user-menu,dashboard-shell,
  stat-card}.tsx` - responsive sidebar (slides in behind a mobile menu
  button below `md`, with a backdrop), sticky topbar, and an avatar
  dropdown (name/email, disabled "Profile settings" placeholder, working
  "Log out")
- Sidebar items beyond "Dashboard" (Servers, Console, Files, Users,
  Settings) are visibly marked "Soon" and non-interactive - no server
  management logic exists yet, as scoped

**Verification performed:** re-confirmed zero live "PowerSpark"
occurrences anywhere in the project (only the intentional historical
changelog entries from the prior rename remain); ran a full TypeScript
syntax check across all 39 new/changed `.ts`/`.tsx` files in `apps/web`,
`packages/ui`, and `packages/types` - all passed; re-validated every
`package.json`/JSON config; cross-referenced every `import` against
declared dependencies - no gaps found this pass.

**Known limitation (same as every prior step):** no outbound network
access in this sandbox, so `pnpm install`, live dev servers, and actually
clicking through the login → dashboard → logout flow in a browser were
not exercised here - verification was static.

**Next step:** Dashboard Foundation (Step 4).

---

## 2026-08-05 — Step 4: Dashboard Foundation

**Type:** Feature (Frontend-heavy, small Backend addition)

Built out the dashboard into a real foundation: a full sidebar and top
navigation, a proper theme system with a working light/dark toggle, toast
notifications, a set of reusable dashboard components, a Dashboard Home
page that actually fetches placeholder data from two new backend
endpoints, and 10 routed placeholder pages for every section named in the
spec. No Minecraft server management, console, file manager, backup,
scheduling, node-management, WebSocket, or resource-monitoring logic was
implemented - everything data-shaped is explicitly static placeholder
data, as scoped. Steps 1-3 (and the Step 3 UI fix) were left untouched;
authentication itself was not modified, only consumed via the existing
`authenticate` middleware and `useAuth()`/`accessToken`.

**Backend (`apps/api`) - new dashboard module:**
- `src/modules/dashboard/dashboard.controller.ts` - `getStats` and
  `getActivity` handlers returning hardcoded placeholder data (server
  counts, CPU/RAM/disk/network percentages, a 12-point history array per
  metric for the charts, and a handful of placeholder activity entries).
  Heavily commented that none of this is real metrics collection
- `src/modules/dashboard/dashboard.routes.ts` - `router.use(authenticate)`
  applied to the whole router, then `GET /stats` and `GET /activity`
- Mounted at `/api/dashboard` in `src/routes/index.ts`

**Shared types (`packages/types`):**
- `src/dashboard.ts` - `DashboardStats`, `ActivityLogEntry`,
  `DashboardActivityResponse`, exported from the package barrel

**Theme system (new, `apps/web`):**
- `src/lib/theme-provider.tsx` - `ThemeProvider`/`useTheme`, defaults to
  dark, toggles the `dark` class on `<html>`, persists to `localStorage`
  under `primespark-theme`
- `src/components/theme-toggle.tsx` - sun/moon icon button for the topbar
- `globals.css` - added real light-theme CSS variable values to `:root`
  (previously identical to `.dark`, effectively dark-only); `.dark`
  keeps the existing blue-accented dark palette unchanged
- Root layout: added a small blocking inline script that removes the
  `dark` class before first paint if `localStorage` says "light", so a
  returning visitor doesn't see a dark-then-light flash

**Toast notifications:**
- Added `sonner`; `src/components/toaster.tsx` wraps `<Toaster />` from
  sonner and syncs its `theme` prop to our own theme context; mounted
  once in the root layout

**Sidebar rebuilt (`components/dashboard/sidebar.tsx`):**
- Full nav list per the spec, extracted to
  `src/lib/dashboard-nav.ts` (`DASHBOARD_NAV_ITEMS`) so the topbar's
  breadcrumbs can reuse the same labels/icons: Dashboard, Servers, Nodes,
  Users, Files, Backups, Schedules, Network, Activity Logs, Settings,
  Account - all real routed links now, not disabled placeholders
- Active-route highlighting via `usePathname()`
- Collapsible on desktop (width animates between `16rem` and `4.5rem`,
  labels hide when collapsed, icons get a `title` tooltip) - state lives
  in `DashboardShell`
- Working "Log out" button at the bottom (`useAuth().logout()` +
  redirect to `/login`)

**Top navigation rebuilt (`components/dashboard/topbar.tsx`):**
- `breadcrumbs.tsx` - derives the trail from the current route against
  `DASHBOARD_NAV_ITEMS`; the last crumb is styled larger/bold, doubling
  as the current-page title
- A presentational global search input (not wired to any search logic)
- `ThemeToggle`
- `notifications-menu.tsx` - dropdown with static placeholder
  notifications and an unread-dot indicator
- Existing `UserMenu` (avatar dropdown, unchanged)

**New reusable dashboard components:**
- `dashboard-card.tsx` - generic titled card wrapper
- `stat-card.tsx` - extended to accept an optional `value`/`hint` instead
  of always showing "-" / "No data yet"
- `chart-card.tsx` - recharts `AreaChart` inside a card, takes a static
  number array; used for the three placeholder trend charts
- `activity-feed.tsx` - renders `ActivityLogEntry[]` with relative
  timestamps; falls back to `EmptyState` when empty
- `quick-actions.tsx` - a 2x2 grid of placeholder action buttons (Create
  Server, Add Node, Invite User, New Backup) that each fire a `sonner`
  toast saying the action isn't available yet, rather than doing nothing
  silently or being disabled
- `empty-state.tsx` / `error-state.tsx` - generic icon + title +
  description (+ optional action/retry) components
- `placeholder-page.tsx` - the shared layout used by every "coming soon"
  section page
- `packages/ui/src/skeleton.tsx` - new shared shadcn/ui `Skeleton`
  primitive

**Dashboard Home (`app/dashboard/page.tsx`) rewritten:**
- On mount, calls `getDashboardStats`/`getDashboardActivity` (in
  parallel) using the access token from `useAuth()`
- Real loading state: a `DashboardSkeleton` composed of `Skeleton` blocks
  matching the eventual layout
- Real error state: `ErrorState` with a "Try again" button that re-runs
  the fetch
- On success: 8 stat cards (Total/Running/Offline Servers, Active Users,
  CPU/RAM/Disk/Network Usage), 3 `ChartCard`s (CPU, RAM, Network
  Traffic), `ActivityFeed`, a static "All systems operational" System
  Status card, and `QuickActions`

**10 new placeholder section pages**
(`app/dashboard/{servers,nodes,users,files,backups,schedules,network,
activity-logs,settings,account}/page.tsx`), each a couple of lines using
`PlaceholderPage` with a distinct icon/title/description - real routes,
real active-state highlighting in the sidebar, no functionality behind
them yet.

**Route protection:** every new page lives under `app/dashboard/`, which
is still wrapped by the existing, unmodified `dashboard/layout.tsx`
(`RequireAuth` + `DashboardShell`). No new auth code was needed or
written - this was purely "reuse what Step 3 already built."

**Verification performed:** full TypeScript syntax check across every
new/changed file in `apps/web`, `packages/ui`, `packages/types` (zero
errors); every `package.json` re-validated as JSON; a complete
import-to-dependency cross-reference (no gaps - `recharts` and `sonner`
were both correctly added to `apps/web`); confirmed zero "PowerSpark"
text anywhere outside the two prior changelog entries that intentionally
name it for history; confirmed `dashboard/layout.tsx` was not modified.

**Known limitation (same as every prior step):** no outbound network
access in this sandbox, so `pnpm install`, live dev servers, and actually
clicking through the dashboard (collapse animation, mobile nav, theme
toggle, toasts, chart rendering) were not exercised in a real browser -
verification was static.

**Next step:** awaiting Step 5.
