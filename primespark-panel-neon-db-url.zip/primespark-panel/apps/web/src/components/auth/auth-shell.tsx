import Link from "next/link";
import { Zap } from "lucide-react";

/**
 * Visual shell shared by every auth page (login, register, forgot/reset
 * password, verify email). Rendered both by the (auth) route group layout
 * and directly by the root "/" page, so "/" and "/login" look identical.
 */
export function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background px-4 py-12">
      {/* Decorative ambient glow - purely visual, no copyrighted assets */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 left-1/2 h-[28rem] w-[28rem] -translate-x-1/2 animate-glow-pulse rounded-full bg-primary/20 blur-[100px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-32 -right-24 h-80 w-80 rounded-full bg-primary/10 blur-[100px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,theme(colors.white/0.03)_1px,transparent_1px),linear-gradient(to_bottom,theme(colors.white/0.03)_1px,transparent_1px)] bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,black,transparent)]"
      />

      <Link href="/" className="relative z-10 mb-10 flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/30">
          <Zap className="h-5 w-5" />
        </span>
        <span className="text-xl font-semibold tracking-tight text-foreground">PrimeSpark Panel</span>
      </Link>

      <div className="relative z-10 w-full max-w-sm animate-fade-in-up">{children}</div>
    </div>
  );
}
