"use client";

import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis } from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@primespark/ui";

interface ChartCardProps {
  title: string;
  description?: string;
  /** Static placeholder series - not derived from any real monitoring. */
  data: number[];
  unit?: string;
  color?: string;
}

export function ChartCard({ title, description, data, unit = "", color = "hsl(var(--primary))" }: ChartCardProps) {
  const points = data.map((value, index) => ({ index, value }));
  const latest = data[data.length - 1];

  return (
    <Card className="border-white/10 bg-white/[0.03] backdrop-blur-xl">
      <CardHeader className="space-y-1 pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
          <span className="text-lg font-semibold tracking-tight text-foreground">
            {latest}
            {unit}
          </span>
        </div>
        {description && <CardDescription className="text-xs">{description}</CardDescription>}
      </CardHeader>
      <CardContent className="h-32 pt-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={points} margin={{ top: 4, right: 0, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id={`chart-fill-${title.replace(/\s+/g, "-")}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.35} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="index" hide />
            <Tooltip
              cursor={false}
              contentStyle={{
                background: "hsl(var(--popover))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "0.5rem",
                fontSize: "0.75rem",
                color: "hsl(var(--popover-foreground))",
              }}
              formatter={(value: number) => [`${value}${unit}`, title]}
              labelFormatter={() => ""}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={2}
              fill={`url(#chart-fill-${title.replace(/\s+/g, "-")})`}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
