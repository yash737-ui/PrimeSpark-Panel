"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronRight } from "lucide-react";
import { DASHBOARD_NAV_ITEMS } from "@/lib/dashboard-nav";

export function Breadcrumbs() {
  const pathname = usePathname();
  const current = DASHBOARD_NAV_ITEMS.find((item) => item.href === pathname) ?? DASHBOARD_NAV_ITEMS[0];
  const crumbs = current.href === "/dashboard" ? [current] : [DASHBOARD_NAV_ITEMS[0], current];

  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1.5">
      {crumbs.map((crumb, index) => {
        const isLast = index === crumbs.length - 1;
        return (
          <span key={crumb.href} className="flex items-center gap-1.5">
            {index > 0 && <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />}
            {isLast ? (
              <span className="text-base font-semibold tracking-tight text-foreground">{crumb.label}</span>
            ) : (
              <Link href={crumb.href} className="text-sm text-muted-foreground hover:text-foreground">
                {crumb.label}
              </Link>
            )}
          </span>
        );
      })}
    </nav>
  );
}
