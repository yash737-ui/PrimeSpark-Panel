"use client";

import { useState } from "react";
import { Sidebar } from "./sidebar";
import { Topbar } from "./topbar";

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Sidebar
        open={mobileNavOpen}
        onClose={() => setMobileNavOpen(false)}
        collapsed={collapsed}
        onToggleCollapsed={() => setCollapsed((prev) => !prev)}
      />

      <div
        className={
          collapsed
            ? "transition-[padding-left] duration-200 ease-out md:pl-[4.5rem]"
            : "transition-[padding-left] duration-200 ease-out md:pl-64"
        }
      >
        <Topbar onMenuClick={() => setMobileNavOpen(true)} />
        <main className="animate-fade-in-up p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}
