import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@primespark/ui";

interface DashboardCardProps {
  title: string;
  description?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}

export function DashboardCard({ title, description, action, children, className }: DashboardCardProps) {
  return (
    <Card className={`border-white/10 bg-white/[0.03] backdrop-blur-xl ${className ?? ""}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0">
        <div className="space-y-1.5">
          <CardTitle className="text-base">{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </div>
        {action}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}
