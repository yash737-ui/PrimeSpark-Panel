"use client";

import { Bell } from "lucide-react";
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@primespark/ui";

// Static placeholder notifications - there is no real notification
// system wired up yet.
const PLACEHOLDER_NOTIFICATIONS = [
  { id: "n1", title: "Welcome to PrimeSpark Panel", time: "Just now" },
  { id: "n2", title: "Your account was created", time: "2h ago" },
];

export function NotificationsMenu() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          <Bell className="h-4 w-4" />
          {PLACEHOLDER_NOTIFICATIONS.length > 0 && (
            <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-primary" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        <DropdownMenuLabel>Notifications</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {PLACEHOLDER_NOTIFICATIONS.length === 0 ? (
          <p className="px-2.5 py-4 text-center text-sm text-muted-foreground">You&apos;re all caught up</p>
        ) : (
          PLACEHOLDER_NOTIFICATIONS.map((notification) => (
            <DropdownMenuItem key={notification.id} className="flex-col items-start gap-0.5">
              <span className="text-sm">{notification.title}</span>
              <span className="text-xs text-muted-foreground">{notification.time}</span>
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
