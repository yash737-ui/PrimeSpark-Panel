import { Card, CardContent, CardHeader, CardTitle } from "@primespark/ui";

interface StatCardProps {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  /** Formatted value to display, e.g. "6", "42%", "12.4 Mbps". Defaults to an em dash. */
  value?: string;
  /** Small helper line under the value, e.g. "of 6 total". Defaults to "No data yet". */
  hint?: string;
}

export function StatCard({ label, icon: Icon, value, hint }: StatCardProps) {
  return (
    <Card className="border-white/10 bg-white/[0.03] backdrop-blur-xl">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-semibold tracking-tight text-foreground">{value ?? "—"}</div>
        <p className="mt-1 text-xs text-muted-foreground">{hint ?? "No data yet"}</p>
      </CardContent>
    </Card>
  );
}
