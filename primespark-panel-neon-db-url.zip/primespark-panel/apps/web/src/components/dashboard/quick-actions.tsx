"use client";

import { toast } from "sonner";
import { PlusCircle, ServerCog, UserPlus, Archive } from "lucide-react";
import { Button } from "@primespark/ui";

const ACTIONS = [
  { label: "Create Server", icon: PlusCircle },
  { label: "Add Node", icon: ServerCog },
  { label: "Invite User", icon: UserPlus },
  { label: "New Backup", icon: Archive },
] as const;

export function QuickActions() {
  return (
    <div className="grid grid-cols-2 gap-2">
      {ACTIONS.map(({ label, icon: Icon }) => (
        <Button
          key={label}
          variant="outline"
          className="h-auto flex-col items-start gap-2 py-3 text-left"
          onClick={() => toast(`${label} isn't available yet`, { description: "This action is a placeholder for a future update." })}
        >
          <Icon className="h-4 w-4 text-primary" />
          <span className="text-xs font-medium">{label}</span>
        </Button>
      ))}
    </div>
  );
}
