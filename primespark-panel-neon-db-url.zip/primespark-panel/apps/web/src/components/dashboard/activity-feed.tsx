import { History } from "lucide-react";
import type { ActivityLogEntry } from "@primespark/types";
import { EmptyState } from "./empty-state";

function formatRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const minutes = Math.round(diffMs / 60_000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}

interface ActivityFeedProps {
  entries: ActivityLogEntry[];
}

export function ActivityFeed({ entries }: ActivityFeedProps) {
  if (entries.length === 0) {
    return (
      <EmptyState
        icon={History}
        title="No activity yet"
        description="Actions taken on your account will show up here."
      />
    );
  }

  return (
    <ul className="divide-y divide-border">
      {entries.map((entry) => (
        <li key={entry.id} className="flex items-start justify-between gap-4 py-3 first:pt-0 last:pb-0">
          <div className="flex items-start gap-3">
            <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
            <div>
              <p className="text-sm text-foreground">{entry.message}</p>
              <p className="text-xs text-muted-foreground">{entry.actor}</p>
            </div>
          </div>
          <span className="shrink-0 text-xs text-muted-foreground">{formatRelativeTime(entry.createdAt)}</span>
        </li>
      ))}
    </ul>
  );
}
