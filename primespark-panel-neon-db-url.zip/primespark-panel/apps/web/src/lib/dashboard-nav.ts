import {
  LayoutDashboard,
  Server,
  Cpu,
  Users,
  FolderOpen,
  Archive,
  Clock,
  Network,
  History,
  Settings,
  CircleUser,
  type LucideIcon,
} from "lucide-react";

export interface DashboardNavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export const DASHBOARD_NAV_ITEMS: DashboardNavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Servers", href: "/dashboard/servers", icon: Server },
  { label: "Nodes", href: "/dashboard/nodes", icon: Cpu },
  { label: "Users", href: "/dashboard/users", icon: Users },
  { label: "Files", href: "/dashboard/files", icon: FolderOpen },
  { label: "Backups", href: "/dashboard/backups", icon: Archive },
  { label: "Schedules", href: "/dashboard/schedules", icon: Clock },
  { label: "Network", href: "/dashboard/network", icon: Network },
  { label: "Activity Logs", href: "/dashboard/activity-logs", icon: History },
  { label: "Settings", href: "/dashboard/settings", icon: Settings },
  { label: "Account", href: "/dashboard/account", icon: CircleUser },
];
