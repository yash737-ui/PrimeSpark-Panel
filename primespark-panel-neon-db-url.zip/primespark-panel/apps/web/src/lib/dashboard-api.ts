import type { ApiSuccessResponse, DashboardActivityResponse, DashboardStats } from "@primespark/types";
import { apiFetch } from "./api-client";

// Dashboard endpoints require the access token (from useAuth()) as a
// Bearer header - this is the same authenticate middleware used
// elsewhere in the API, just called with the token the caller already
// has in memory rather than adding any new auth mechanism.
function authHeaders(accessToken: string) {
  return { Authorization: `Bearer ${accessToken}` };
}

export function getDashboardStats(accessToken: string) {
  return apiFetch<ApiSuccessResponse<DashboardStats>>("/api/dashboard/stats", {
    headers: authHeaders(accessToken),
  });
}

export function getDashboardActivity(accessToken: string) {
  return apiFetch<ApiSuccessResponse<DashboardActivityResponse>>("/api/dashboard/activity", {
    headers: authHeaders(accessToken),
  });
}
