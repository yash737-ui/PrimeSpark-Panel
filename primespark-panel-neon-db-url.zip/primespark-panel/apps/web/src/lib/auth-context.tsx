"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { AuthUser, LoginInput, RegisterInput } from "@primespark/types";
import { loginRequest, logoutRequest, refreshRequest, registerRequest } from "./auth-api";

interface AuthContextValue {
  user: AuthUser | null;
  accessToken: string | null;
  /** True until the initial silent-refresh bootstrap has resolved. */
  isLoading: boolean;
  login: (input: LoginInput) => Promise<void>;
  register: (input: RegisterInput) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

/**
 * Wraps the app and establishes whether there is an authenticated session.
 * Access tokens are short-lived and kept in memory only (never in
 * localStorage), so on first load we silently try to exchange the
 * httpOnly refresh cookie for a new access token. If that succeeds the
 * user is signed in transparently; if it fails they're treated as a guest.
 */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    refreshRequest()
      .then((res) => {
        if (cancelled) return;
        setUser(res.data.user);
        setAccessToken(res.data.accessToken);
      })
      .catch(() => {
        if (cancelled) return;
        setUser(null);
        setAccessToken(null);
      })
      .finally(() => {
        if (!cancelled) setIsLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(async (input: LoginInput) => {
    const res = await loginRequest(input);
    setUser(res.data.user);
    setAccessToken(res.data.accessToken);
  }, []);

  const register = useCallback(async (input: RegisterInput) => {
    const res = await registerRequest(input);
    setUser(res.data.user);
    setAccessToken(res.data.accessToken);
  }, []);

  const logout = useCallback(async () => {
    await logoutRequest().catch(() => {
      // Even if the network call fails, clear local state so the UI
      // reflects a logged-out session.
    });
    setUser(null);
    setAccessToken(null);
  }, []);

  const value = useMemo(
    () => ({ user, accessToken, isLoading, login, register, logout }),
    [user, accessToken, isLoading, login, register, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}
