import { History } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function ActivityLogsPage() {
  return (
    <PlaceholderPage
      title="Activity Logs"
      description="A full history of actions taken across your account."
      icon={History}
      emptyTitle="No activity logs yet"
      emptyDescription="A detailed activity log will be available in a future update."
    />
  );
}
