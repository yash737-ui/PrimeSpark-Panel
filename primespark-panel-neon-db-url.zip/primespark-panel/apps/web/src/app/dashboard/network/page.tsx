import { Network } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function NetworkPage() {
  return (
    <PlaceholderPage
      title="Network"
      description="Manage allocations, ports, and network settings."
      icon={Network}
      emptyTitle="No network data yet"
      emptyDescription="Network management will be available in a future update."
    />
  );
}
