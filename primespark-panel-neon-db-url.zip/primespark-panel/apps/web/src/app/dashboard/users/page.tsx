import { Users } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function UsersPage() {
  return (
    <PlaceholderPage
      title="Users"
      description="Manage who has access to PrimeSpark Panel."
      icon={Users}
      emptyTitle="No users to show"
      emptyDescription="User management will be available in a future update."
    />
  );
}
