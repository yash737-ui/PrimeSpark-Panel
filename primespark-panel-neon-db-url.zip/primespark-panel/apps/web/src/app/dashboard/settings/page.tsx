import { Settings } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function SettingsPage() {
  return (
    <PlaceholderPage
      title="Settings"
      description="Configure PrimeSpark Panel for your environment."
      icon={Settings}
      emptyTitle="Nothing to configure yet"
      emptyDescription="Panel settings will be available in a future update."
    />
  );
}
