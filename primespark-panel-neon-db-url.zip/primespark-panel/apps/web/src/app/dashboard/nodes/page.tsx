import { Cpu } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function NodesPage() {
  return (
    <PlaceholderPage
      title="Nodes"
      description="The machines that host your servers."
      icon={Cpu}
      emptyTitle="No nodes yet"
      emptyDescription="Node management will be available in a future update."
    />
  );
}
