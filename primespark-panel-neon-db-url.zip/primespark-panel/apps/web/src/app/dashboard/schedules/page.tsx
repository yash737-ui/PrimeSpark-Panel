import { Clock } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function SchedulesPage() {
  return (
    <PlaceholderPage
      title="Schedules"
      description="Automate recurring server tasks."
      icon={Clock}
      emptyTitle="No schedules yet"
      emptyDescription="Scheduling functionality will be available in a future update."
    />
  );
}
