import { FolderOpen } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function FilesPage() {
  return (
    <PlaceholderPage
      title="Files"
      description="Browse and edit files on your servers."
      icon={FolderOpen}
      emptyTitle="No files to show"
      emptyDescription="The file manager will be available in a future update."
    />
  );
}
