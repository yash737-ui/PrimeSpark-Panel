"use client";

import { useCallback, useEffect, useState } from "react";
import { Server, Activity, HardDrive, Cpu, MemoryStick, Wifi, Users as UsersIcon, CheckCircle2 } from "lucide-react";
import type { ActivityLogEntry, DashboardStats } from "@primespark/types";
import { Skeleton } from "@primespark/ui";
import { useAuth } from "@/lib/auth-context";
import { getDashboardActivity, getDashboardStats } from "@/lib/dashboard-api";
import { ApiError } from "@/lib/api-client";
import { StatCard } from "@/components/dashboard/stat-card";
import { ChartCard } from "@/components/dashboard/chart-card";
import { DashboardCard } from "@/components/dashboard/dashboard-card";
import { ActivityFeed } from "@/components/dashboard/activity-feed";
import { QuickActions } from "@/components/dashboard/quick-actions";
import { ErrorState } from "@/components/dashboard/error-state";

interface DashboardData {
  stats: DashboardStats;
  activity: ActivityLogEntry[];
}

export default function DashboardPage() {
  const { user, accessToken } = useAuth();
  const displayName = user?.name?.trim() || user?.email || "there";

  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const loadDashboard = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true);
    setError(null);
    try {
      const [statsRes, activityRes] = await Promise.all([
        getDashboardStats(accessToken),
        getDashboardActivity(accessToken),
      ]);
      setData({ stats: statsRes.data, activity: activityRes.data.entries });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't load your dashboard.");
    } finally {
      setLoading(false);
    }
  }, [accessToken]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Welcome back, {displayName}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Here&apos;s an overview of your PrimeSpark Panel account.
        </p>
      </div>

      {error && <ErrorState description={error} onRetry={loadDashboard} />}

      {!error && loading && <DashboardSkeleton />}

      {!error && !loading && data && (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Total Servers" icon={Server} value={String(data.stats.totalServers)} hint="Across all nodes" />
            <StatCard
              label="Running Servers"
              icon={Activity}
              value={String(data.stats.runningServers)}
              hint={`of ${data.stats.totalServers} total`}
            />
            <StatCard
              label="Offline Servers"
              icon={Server}
              value={String(data.stats.offlineServers)}
              hint="Stopped or crashed"
            />
            <StatCard label="Active Users" icon={UsersIcon} value={String(data.stats.activeUsers)} hint="Signed in recently" />
            <StatCard label="CPU Usage" icon={Cpu} value={`${data.stats.cpuUsagePercent}%`} hint="Across all nodes" />
            <StatCard label="RAM Usage" icon={MemoryStick} value={`${data.stats.ramUsagePercent}%`} hint="Across all nodes" />
            <StatCard label="Disk Usage" icon={HardDrive} value={`${data.stats.diskUsagePercent}%`} hint="Across all nodes" />
            <StatCard label="Network Usage" icon={Wifi} value={`${data.stats.networkUsageMbps} Mbps`} hint="Current throughput" />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <ChartCard title="CPU Usage" description="Last 12 samples" data={data.stats.cpuHistory} unit="%" />
            <ChartCard title="RAM Usage" description="Last 12 samples" data={data.stats.ramHistory} unit="%" color="#22c55e" />
            <ChartCard
              title="Network Traffic"
              description="Last 12 samples"
              data={data.stats.networkHistory}
              unit=" Mbps"
              color="#f59e0b"
            />
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <DashboardCard title="Recent Activity" description="What's happened on your account" className="lg:col-span-2">
              <ActivityFeed entries={data.activity} />
            </DashboardCard>

            <div className="space-y-4">
              <DashboardCard title="System Status" description="Overall platform health">
                <div className="flex items-center gap-2 rounded-lg border border-primary/20 bg-primary/5 px-3 py-2.5">
                  <CheckCircle2 className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium text-foreground">All systems operational</span>
                </div>
              </DashboardCard>

              <DashboardCard title="Quick Actions" description="Common shortcuts">
                <QuickActions />
              </DashboardCard>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-28 w-full rounded-xl" />
        ))}
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-48 w-full rounded-xl" />
        ))}
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Skeleton className="h-64 w-full rounded-xl lg:col-span-2" />
        <div className="space-y-4">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-40 w-full rounded-xl" />
        </div>
      </div>
    </div>
  );
}
