import { Server } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function ServersPage() {
  return (
    <PlaceholderPage
      title="Servers"
      description="Manage and monitor your Minecraft server instances."
      icon={Server}
      emptyTitle="No servers yet"
      emptyDescription="Server creation and management will be available in a future update."
    />
  );
}
