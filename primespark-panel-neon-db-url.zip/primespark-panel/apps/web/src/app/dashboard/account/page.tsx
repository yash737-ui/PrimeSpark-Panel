import { CircleUser } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function AccountPage() {
  return (
    <PlaceholderPage
      title="Account"
      description="Manage your profile, password, and security settings."
      icon={CircleUser}
      emptyTitle="Account settings coming soon"
      emptyDescription="Profile editing and security settings will be available in a future update."
    />
  );
}
