import { Archive } from "lucide-react";
import { PlaceholderPage } from "@/components/dashboard/placeholder-page";

export default function BackupsPage() {
  return (
    <PlaceholderPage
      title="Backups"
      description="Protect your server data with scheduled backups."
      icon={Archive}
      emptyTitle="No backups yet"
      emptyDescription="Backup functionality will be available in a future update."
    />
  );
}
