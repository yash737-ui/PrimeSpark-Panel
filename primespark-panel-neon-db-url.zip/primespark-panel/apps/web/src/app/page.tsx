import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/login-form";
import { RequireGuest } from "@/components/auth/require-guest";

// The root route is the login page itself, not a marketing site. "/" and
// "/login" render identical content - kept as separate files (rather than
// a redirect) so the URL bar reads "/" for people landing on the bare
// domain, matching how most hosting control panels behave.
export default function RootPage() {
  return (
    <AuthShell>
      <RequireGuest>
        <LoginForm />
      </RequireGuest>
    </AuthShell>
  );
}
