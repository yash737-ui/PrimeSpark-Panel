import { Suspense } from "react";
import { VerifyEmailContent } from "@/components/auth/verify-email-content";

// Not guest-gated: registering logs a user in immediately, so most people
// who click a verification link are already authenticated when they land
// here. Gating this page to guests-only would lock them out of it.
export default function VerifyEmailPage() {
  return (
    <Suspense fallback={null}>
      <VerifyEmailContent />
    </Suspense>
  );
}
