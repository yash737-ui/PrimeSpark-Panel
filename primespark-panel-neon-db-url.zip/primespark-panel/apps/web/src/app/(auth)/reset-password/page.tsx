import { Suspense } from "react";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";

// Not guest-gated: a signed-in user may still follow a password-reset
// link (e.g. from an old email), and resetting invalidates their other
// sessions server-side regardless of whether they were logged in here.
export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetPasswordForm />
    </Suspense>
  );
}
