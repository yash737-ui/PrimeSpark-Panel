import { RegisterForm } from "@/components/auth/register-form";
import { RequireGuest } from "@/components/auth/require-guest";

export default function RegisterPage() {
  return (
    <RequireGuest>
      <RegisterForm />
    </RequireGuest>
  );
}
