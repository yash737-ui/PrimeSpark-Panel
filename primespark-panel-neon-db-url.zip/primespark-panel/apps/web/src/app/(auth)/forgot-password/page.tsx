import { ForgotPasswordForm } from "@/components/auth/forgot-password-form";
import { RequireGuest } from "@/components/auth/require-guest";

export default function ForgotPasswordPage() {
  return (
    <RequireGuest>
      <ForgotPasswordForm />
    </RequireGuest>
  );
}
