import { LoginForm } from "@/components/auth/login-form";
import { RequireGuest } from "@/components/auth/require-guest";

export default function LoginPage() {
  return (
    <RequireGuest>
      <LoginForm />
    </RequireGuest>
  );
}
