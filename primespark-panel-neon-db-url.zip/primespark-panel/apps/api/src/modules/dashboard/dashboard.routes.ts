import { Router } from "express";
import { authenticate } from "../../middleware/authenticate";
import * as dashboardController from "./dashboard.controller";

const router = Router();

// Every dashboard route requires a valid access token. Unauthenticated
// requests receive a 401 here; the frontend's RequireAuth guard is what
// turns that into a redirect to /login in the browser.
router.use(authenticate);

router.get("/stats", dashboardController.getStats);
router.get("/activity", dashboardController.getActivity);

export default router;
