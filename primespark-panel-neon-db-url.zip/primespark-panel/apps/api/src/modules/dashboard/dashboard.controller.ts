import type { Request, Response } from "express";
import type { ActivityLogEntry, DashboardStats } from "@primespark/types";

// PrimeSpark Panel - Dashboard Controller (placeholder)
// Returns static placeholder data only. There is no real metrics
// collection, resource monitoring, or server-management logic behind
// these endpoints yet - they exist so the dashboard UI has something to
// render against while that logic is built in a future step.

const PLACEHOLDER_STATS: DashboardStats = {
  totalServers: 6,
  runningServers: 4,
  offlineServers: 2,
  cpuUsagePercent: 42,
  ramUsagePercent: 58,
  diskUsagePercent: 31,
  networkUsageMbps: 12.4,
  activeUsers: 3,
  systemStatus: "operational",
  cpuHistory: [18, 22, 20, 26, 31, 28, 35, 40, 38, 42, 39, 42],
  ramHistory: [40, 42, 45, 44, 48, 50, 52, 55, 53, 57, 56, 58],
  networkHistory: [3.2, 4.1, 3.8, 5.6, 6.2, 5.9, 8.1, 9.4, 8.8, 10.2, 11.1, 12.4],
};

const PLACEHOLDER_ACTIVITY: ActivityLogEntry[] = [
  {
    id: "act_1",
    message: "Signed in to PrimeSpark Panel",
    actor: "You",
    createdAt: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
  },
  {
    id: "act_2",
    message: "Account created",
    actor: "You",
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "act_3",
    message: "Welcome to PrimeSpark Panel",
    actor: "System",
    createdAt: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
  },
];

export async function getStats(_req: Request, res: Response) {
  res.status(200).json({ status: "success", data: PLACEHOLDER_STATS });
}

export async function getActivity(_req: Request, res: Response) {
  res.status(200).json({ status: "success", data: { entries: PLACEHOLDER_ACTIVITY } });
}
