import "dotenv/config";
import { prisma } from "../src/lib/prisma";

/**
 * PrimeSpark Panel - Admin Promotion Script
 *
 * Promotes an already-registered user to the ADMIN role. This is a
 * database-level operation run directly by whoever has server/DB access -
 * it is intentionally NOT exposed as an API endpoint, so there is no way
 * to self-promote to ADMIN through the app itself. Authentication and
 * RBAC (`authenticate`/`authorize` middleware) are completely untouched;
 * this script only ever changes the `role` column via Prisma.
 *
 * Usage:
 *   pnpm --filter @primespark/api run promote-admin -- <email>
 *
 * The user must already exist (i.e. have registered through the normal
 * /api/auth/register flow, with their own password) - this script never
 * creates a user or sets/knows a password. It only flips role: USER -> ADMIN.
 */

async function main() {
  const email = process.argv[2]?.trim();

  if (!email) {
    console.error("Usage: pnpm --filter @primespark/api run promote-admin -- <email>");
    process.exitCode = 1;
    return;
  }

  const user = await prisma.user.findUnique({ where: { email } });

  if (!user) {
    console.error(
      `No user found with email "${email}". They need to register through the app first ` +
        `(POST /api/auth/register or the /register page) - this script only promotes an ` +
        `existing account, it never creates one.`,
    );
    process.exitCode = 1;
    return;
  }

  if (user.role === "ADMIN") {
    console.log(`"${email}" is already ADMIN (id: ${user.id}). Nothing to change.`);
    return;
  }

  await prisma.user.update({
    where: { email },
    data: { role: "ADMIN" },
  });

  // Re-read the row back from Postgres (rather than trusting the update's
  // return value) so the confirmation below reflects what's actually
  // persisted in the database.
  const verified = await prisma.user.findUniqueOrThrow({ where: { email } });

  console.log(`✔ "${verified.email}" is now role=${verified.role} (id: ${verified.id}).`);
  console.log("Verified by re-reading the row from PostgreSQL after the update.");
}

main()
  .catch((error) => {
    console.error("Failed to promote user to ADMIN:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
